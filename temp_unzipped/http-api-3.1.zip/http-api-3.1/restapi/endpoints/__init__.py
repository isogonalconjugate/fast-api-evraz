"""
Definition of all core endpoints
"""
