from restapi.config import DOCS, HOST_TYPE
from restapi.connectors import celery
from restapi.server import ServerModes, create_app
from restapi.utilities.logs import log

instance = celery.get_instance()
# Used by Celery to run the instance (--app app)
celery_app = instance.celery_app

if HOST_TYPE != DOCS:
    # Reload Flask app code for the worker (needed to have the app context available)
    celery.CeleryExt.app = create_app(
        name="Celery Worker", mode=ServerModes.WORKER, options={}
    )

    log.debug("Celery worker is ready {}", celery_app)
