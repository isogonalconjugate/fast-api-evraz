"""
Management of the RESTful protocol and best practices
"""
