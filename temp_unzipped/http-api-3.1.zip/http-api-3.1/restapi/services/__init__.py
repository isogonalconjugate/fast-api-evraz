"""
Definition and management of additional services like authentication, caching,
download and upload utilities
"""
