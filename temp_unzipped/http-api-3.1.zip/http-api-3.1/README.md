# RAPyDo REST APIs

REST APIs integrated with the RAPyDo framework

Based on:

- Flask
- flask-apispec with apispec
- marshmallow
- webargs
- Flask-Caching
- PyJWT
- pyotp With segno
- Neomodel
- SQLAlchemy
- Redis-py
- pika with amqp
- celery with celery-redbeat
- gunicorn with gevent
